# 🔐 SIEM Query Prompt Pack
### 1. Write a Splunk query to detect brute‑force login attempts.

### 2. Convert this KQL query to SPL: [paste query].

### 3. Create a QRadar rule to detect lateral movement.

### 4. What indicators should I look for in SIEM to detect data exfiltration?

### 5. Generate a dashboard layout for SOC monitoring [tool name].
