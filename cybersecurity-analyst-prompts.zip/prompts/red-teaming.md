# ⚔️ Red Teaming Prompt Pack
### 1. Generate a basic pentest checklist for a web app.

### 2. Simulate a phishing pretext scenario for social engineering.

### 3. List tools for privilege escalation on Linux.

### 4. Write a report summary for an internal network penetration test.

### 5. Create a C2 simulation plan using open‑source tools.
