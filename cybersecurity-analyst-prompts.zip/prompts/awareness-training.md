# 🎓 Security Awareness & Training Prompt Pack
### 1. Create a phishing awareness quiz for employees.

### 2. Draft a monthly cybersecurity awareness newsletter.

### 3. Summarize best practices for password security.

### 4. Design a 5‑slide presentation on social engineering risks.

### 5. Write a script for an internal training video on MFA.
