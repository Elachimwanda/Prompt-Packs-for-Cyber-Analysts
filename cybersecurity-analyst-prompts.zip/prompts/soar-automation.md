# 🤖 SOAR & Automation Prompt Pack
### 1. Design a SOAR workflow for phishing ticket triage.

### 2. List use cases for automating malware sandboxing.

### 3. Create a playbook for auto‑blocking malicious IPs using [tool].

### 4. What are key metrics to track SOAR performance?

### 5. Suggest automation scripts for repetitive SOC tasks.
