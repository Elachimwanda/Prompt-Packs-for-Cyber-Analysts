# 📑 Compliance & Governance Prompt Pack
### 1. Map this control to ISO 27001: [paste control].

### 2. Explain how this policy supports NIST CSF compliance.

### 3. Generate a GDPR compliance checklist for data processors.

### 4. Draft a security policy for removable media use.

### 5. Summarize how to prepare for a SOC 2 Type 2 audit.
