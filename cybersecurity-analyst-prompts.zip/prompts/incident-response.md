# 🚨 Incident Response Prompt Pack
### 1. Create an IR playbook for ransomware detection.

### 2. What are the steps to contain a phishing attack?

### 3. Draft a communication template for informing stakeholders of a breach.

### 4. List forensic artifacts to collect during endpoint compromise.

### 5. Summarize NIST 800‑61 steps for incident response.
