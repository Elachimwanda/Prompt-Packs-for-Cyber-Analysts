# 🔍 Threat Intelligence Prompt Pack
### 1. Summarize the latest threat intelligence from [URL/source].

### 2. List the top 5 active APT groups targeting [sector/region].

### 3. Extract IOCs from this text or threat report.

### 4. Correlate these IOCs with known campaigns.

### 5. Provide a TTP mapping using MITRE ATT&CK for this attack scenario.
