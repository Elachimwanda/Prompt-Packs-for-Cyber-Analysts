# ☁️ Cloud Security Prompt Pack
### 1. List misconfigurations that lead to S3 bucket exposure.

### 2. Write an Azure Policy to deny public IPs on VMs.

### 3. Create a checklist for securing GCP workloads.

### 4. Explain shared responsibility in AWS cloud security.

### 5. Generate IAM least privilege policy for an app using AWS Lambda.
